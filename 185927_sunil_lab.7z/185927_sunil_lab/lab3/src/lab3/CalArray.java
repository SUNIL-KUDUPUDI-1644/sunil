package lab3;
import java.util.*;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
class CalArray {
	public int[] getSorted(int[] a) {
		int k=0;
		int b[]=new int[a.length];
		  for(int i=a.length;i>0;i--);
		  {
			  int i=0;
			b[k]=a[i];
			  k++;
			  System.out.println(b[k]);
			  
		  }
		  Arrays.sort(b);
		  return b;
		  
		
	}

	public static void main(String[] args)
	{
		System.out.println("enter the no of elements in the array");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("enter the elements of an array");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i] =sc.nextInt();
			
		}
		CalArray a1=new CalArray();
		int res[] =a1.getSorted(a);
		for(int i=0;i<n;i++)
		{
			System.out.println(res[i]);
		}
	}
	}
